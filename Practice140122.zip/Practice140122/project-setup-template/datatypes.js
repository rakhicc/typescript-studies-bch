var Role;
(function (Role) {
    Role["ADMIN"] = "admin";
    Role[Role["READONLY"] = 100] = "READONLY";
    Role["AUTHOR"] = "AUTHOR";
})(Role || (Role = {}));
var person = {
    name: "rakhi",
    age: 31
};
console.log(person.name);
var product = {
    id: "abc1",
    price: 12.99,
    role: Role.ADMIN,
    tags: ["great-offer", "hot-and-new"],
    details: {
        title: "Red Carpet",
        description: "Agreat carpet - almost brand-new!"
    }
};
console.log(product.details.description);
var anotherperson = {
    name: "rakhi",
    hobbies: ["cooking", "reading", "writing"],
    role: [2, "author"]
};
console.log(anotherperson.role[0]);
var favouriteactivities;
favouriteactivities = ["cooking", "reading"];
for (var _i = 0, _a = anotherperson.hobbies; _i < _a.length; _i++) {
    var hobby = _a[_i];
    console.log(hobby.toUpperCase);
}
console.log(favouriteactivities);
var admin = 0;
var readonly = 1;
var author = 2;
if (product.role === Role.ADMIN) {
    console.log("its read only");
}
console.log("hi");
console.log("hello");
