type Combinable = number | string;
type ConversionDescription = "as-number" | "as-text";

function combine(
  input1: Combinable,
  input2: Combinable,
  resultconversion: ConversionDescription
) {
  let result;
  if (
    (typeof input1 === "number" && typeof input2 === "number") ||
    resultconversion === "as-number"
  ) {
    result = +input1 + +input2;
  } else {
    result = input1.toString() + input2.toString();
  }
  return result;
}
const combineages = combine(34, 33, "as-number");
console.log(combineages);
const combinenames = combine("james", "rakhi", "as-text");
console.log(combinenames);

type User = { name: string; age: number };
const u1: User = { name: "Max", age: 29 };
console.log(u1);
type Product = { title: string; price: number };
const p1: Product = { title: "ABook", price: 12.99 };
console.log(p1);
