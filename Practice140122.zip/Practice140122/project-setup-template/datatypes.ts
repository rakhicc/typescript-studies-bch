enum Role {
  ADMIN = "admin",
  READONLY = 100,
  AUTHOR = "AUTHOR",
}

const person: {
  name: string;
  age: number;
} = {
  name: "rakhi",
  age: 31,
};
console.log(person.name);
const product = {
  id: "abc1",
  price: 12.99,
  role: Role.ADMIN,
  tags: ["great-offer", "hot-and-new"],
  details: {
    title: "Red Carpet",
    description: "Agreat carpet - almost brand-new!",
  },
};
console.log(product.details.description);
const anotherperson = {
  name: "rakhi",
  hobbies: ["cooking", "reading", "writing"],
  role: [2, "author"],
};
console.log(anotherperson.role[0]);
let favouriteactivities: string[];
favouriteactivities = ["cooking", "reading"];

for (const hobby of anotherperson.hobbies) {
  console.log(hobby.toUpperCase);
}
console.log(favouriteactivities);
const admin = 0;
const readonly = 1;
const author = 2;
if (product.role === Role.ADMIN) {
  console.log("its read only");
}
console.log("hi");
console.log("hello");
