"use strict";
function combine(input1, input2, resultconversion) {
    let result;
    if ((typeof input1 === "number" && typeof input2 === "number") ||
        resultconversion === "as-number") {
        result = +input1 + +input2;
    }
    else {
        result = input1.toString() + input2.toString();
    }
    return result;
}
const combineages = combine(34, 33, "as-number");
console.log(combineages);
const combinenames = combine("james", "rakhi", "as-text");
console.log(combinenames);
const u1 = { name: "Max", age: 29 };
console.log(u1);
const p1 = { title: "ABook", price: 12.99 };
console.log(p1);
