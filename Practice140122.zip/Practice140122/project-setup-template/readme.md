##steps to follow for typescript node project
npm install
npm start
tsc --init to create tsconfig.json file
"watch": true
tsc in another vs code terminal
