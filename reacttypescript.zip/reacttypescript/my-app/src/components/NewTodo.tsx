import React, { useRef } from "react";
import "./Newtodo.css";
type NewTodoProps = {
  onAddTodo: (todoText: string) => void; //function type
};
const NewTodo: React.FC<NewTodoProps> = (props) => {
  const textInputRef = useRef<HTMLInputElement>(null);
  const todoSubmitHandler = (event: React.FormEvent) => {
    event.preventDefault();
    let enteredText = textInputRef.current!.value;
    console.log(enteredText);
    if (textInputRef.current!.value.trim().length > 0) {
      props.onAddTodo(enteredText);
      textInputRef.current!.value = "";
    } else {
      alert("please write something");
    }
  };

  return (
    <form onSubmit={todoSubmitHandler}>
      <div>
        <label htmlFor="todo-text">Todo Text</label>
        <input type="text" id="todo-text" ref={textInputRef}></input>
      </div>
      <button type="submit">Add Todo</button>
    </form>
  );
};

export default NewTodo;
