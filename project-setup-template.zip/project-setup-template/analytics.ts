console.log("analytics");
function add(
  a: number,
  b: number,
  printCb: (string: string, any: any) => void
) {
  printCb("result", a + b);
}
function prettyPrint(label: string, val: any) {
  console.log(`${label} : ${val}`);
  console.log("---------------\n");
}
add(5, 2, prettyPrint);
console.log("exclude");
function sendRequest(data: string, cb: (response: any) => void) {
  // ... sending a request with "data"
  return cb({ data: "Hi there!" });
}
sendRequest("Send this!", (response) => {
  console.log(response);
  return true;
});

const button = document.querySelector("button");
button.addEventListener("click", () => {
  console.log("clicked");
});
