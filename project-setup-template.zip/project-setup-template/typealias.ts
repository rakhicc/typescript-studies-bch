console.log("Your code goes here...");
/* const logDetails = (uid: string | number, item: string) => 
{   console.log(`${item} has a uid of ${uid}`); };  */

/* const greet = (user: { name: string; uid: string | number }) => 
{   console.log(`${user.name} says hello`); }; */

type Stringornum = string | number;
type objwithname = { name: string; uid: Stringornum };
const logDetails = (uid: Stringornum, item: string) => {
  console.log(`${item} has a uid of ${uid}`);
};
const greet = (user: objwithname) => {
  console.log(`${user.name} says hello`);
};

console.log(logDetails(1, "james"));
console.log(greet({ name: "james", uid: 25 }));
