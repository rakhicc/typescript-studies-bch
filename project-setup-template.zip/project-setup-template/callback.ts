function printResult(num: number): void {
  console.log("Result " + num);

  function add(
    a: number,
    b: number,
    printCb: (string: string, any: any) => void
  ) {
    printCb("result", a + b);
  }
  function prettyPrint(label: string, val: any) {
    console.log(`${label} : ${val}`);
    console.log("---------------\n");
  }

  add(5, 2, prettyPrint);
}

function sendRequest1(data: string, cb: (response: any) => void) {
  // ... sending a request with "data"
  return cb({ data: "Hi there!" });
}
sendRequest1("Send this!", (response) => {
  console.log(response);
  return true;
});
