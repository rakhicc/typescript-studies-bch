function addition(n1: number, n2: number): number {
  return n1 + n2;
}
console.log(addition(2, 3));
function printresult(num: number): void {
  console.log("Result:" + num);
}
function printresultagain(num: number): void {
  console.log("Result:" + num);
}
printresultagain(addition(5, 12));
