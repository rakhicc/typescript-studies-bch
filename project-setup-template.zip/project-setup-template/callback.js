"use strict";
function printResult(num) {
    console.log("Result " + num);
    function add(a, b, printCb) {
        printCb("result", a + b);
    }
    function prettyPrint(label, val) {
        console.log(`${label} : ${val}`);
        console.log("---------------\n");
    }
    add(5, 2, prettyPrint);
}
function sendRequest(data, cb) {
    // ... sending a request with "data"
    return cb({ data: "Hi there!" });
}
sendRequest("Send this!", (response) => {
    console.log(response);
    return true;
});
