"use strict";
console.log("Your code goes here...");
const logDetails = (uid, item) => {
    console.log(`${item} has a uid of ${uid}`);
};
const greet = (user) => {
    console.log(`${user.name} says hello`);
};
console.log(logDetails(1, "james"));
console.log(greet({ name: "james", uid: 25 }));
