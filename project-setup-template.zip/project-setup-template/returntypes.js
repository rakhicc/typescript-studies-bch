"use strict";
function addition(n1, n2) {
    return n1 + n2;
}
console.log(addition(2, 3));
function printresult(num) {
    console.log("Result:" + num);
}
function printresultagain(num) {
    console.log("Result:" + num);
}
printresultagain(addition(5, 12));
