"use strict";
console.log("analytics");
function add(a, b, printCb) {
    printCb("result", a + b);
}
function prettyPrint(label, val) {
    console.log(`${label} : ${val}`);
    console.log("---------------\n");
}
add(5, 2, prettyPrint);
console.log("exclude");
function sendRequest(data, cb) {
    // ... sending a request with "data"
    return cb({ data: "Hi there!" });
}
sendRequest("Send this!", (response) => {
    console.log(response);
    return true;
});
const button = document.querySelector("button");
button.addEventListener("click", () => {
    console.log("clicked");
});
