console.log("weclome to decorators example");
//decorator is a function
function Logger(constructor: Function) {
  console.log("logging...");
  console.log(constructor);
}

@Logger
class Person {
  name = "James";
  constructor() {
    console.log("creating a person object");
  }
}

//creating a person object
const personObj = new Person();
console.log(personObj);

//method bind or autobind annotation is required for binding a method to dom element
class Printer {
  message = "this works";
  //method to show message
  showMessage() {
    console.log(this.message);
  }
}

const p = new Printer();
const button = document.querySelector("button")!;
button.addEventListener("click", p.showMessage.bind(p));

//generics example
/* type numArray = Array<number>;
type arr = Array<string>; */

const last = (array: Array<any>) => {
  return array[array.length - 1];
};
const l = last([1, 2, 3]);

console.log(l);

const l1 = last(["a", "b", "c"]);

console.log(l1);

// the above example of last method can be modified using generics as follows:
const lastmodified = <T>(arr: T[]) => {
  return arr[arr.length - 1];
};
const l3 = lastmodified([1, 2, 3]);

console.log(l3);

const l4 = lastmodified(["a", "b", "c"]);

console.log(l4);

//interface example
interface SuperPerson {
  name: string;
  age: number;
  greet(phase: string): void;
}

let user1: SuperPerson;
user1 = {
  name: "james",
  age: 34,
  greet(phrase: string) {
    console.log(phrase + " " + this.name);
  },
};
user1.greet("hi there I am");
