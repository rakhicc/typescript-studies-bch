// import Drag and drop interface

// creating a re-usable validation functionality

// decorator is a function, autobind decorator
import { ProjectInput } from "./components/project-input";
import { ProjectList } from "./components/project-list";
new ProjectInput();
new ProjectList("active");
new ProjectList("finished");
