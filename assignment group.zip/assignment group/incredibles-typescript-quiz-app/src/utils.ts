export const shufflearray = (array:any[])=>
[...array].sort(()=> Math.random()-0.5)