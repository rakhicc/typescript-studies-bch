# Location App

This mini project is used for finding the location using TS

# Steps to follow

1. `npm install` (to install webpack and other dependencies)
2. `npm start` (to start the webpack)
3. You can check the `localhost:9000`

# LocationApp (step-by-step)

LocationApp using TS

# Use for reference

Use solely for reference material only
